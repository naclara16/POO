
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Pessoa p1 = new Pessoa();
        Aluno p2 = new Aluno();
        Professor p3 = new Professor();
        Funcionario p4 = new Funcionario();
        Scanner leia = new Scanner(System.in);

        System.out.println("-------------------------");
        System.out.println("Pessoa");
        System.out.println("Digite seu nome: ");
        p1.setNome(leia.nextLine());
        System.out.println("Digite sua idade: ");
        p1.setIdade(leia.nextInt());
        System.out.println("Digite seu sexo: ");
        p1.setSexo(leia.next());
        p1.print();

        System.out.println("------------------------");
        System.out.println("Aluno");
        System.out.println("Digite seu nome: ");
        p2.setNome(leia.next());
        System.out.println("Digite sua idade: ");
        p2.setIdade(leia.nextInt());
        System.out.println("Digite seu Sexo: ");
        p2.setSexo(leia.next());
        System.out.println("Digite seu Curso: ");
        p2.setCurso(leia.next());
        System.out.println("Digite sua matricula: ");
        p2.setMat(leia.nextInt());
        p2.print();

        System.out.println("------------------------");
        System.out.println("Professor");
        System.out.println("Digite seu nome: ");
        p3.setNome(leia.next());
        System.out.println("Digite sua Idade: ");
        p3.setIdade(leia.nextInt());
        System.out.println("Digite seu Sexo: ");
        p3.setSexo(leia.next());
        System.out.println("Digite sua especialidade:  ");
        p3.setEspecialidade(leia.next());
        System.out.println("Digite seu Salario: ");
        p3.setSalario(leia.nextFloat());
        p3.receberAumento(500);
        p3.print();

        System.out.println("----------------------------");
        System.out.println("Funcionario");
        System.out.println("Digite seu nome: ");
        p4.setNome(leia.next());
        System.out.println("Digite sua idade: ");
        p4.setIdade(leia.nextInt());
        System.out.println("Digite seu Sexo: ");
        p4.setSexo(leia.next());
        System.out.println("Digite seu Setor: ");
        p4.setSetor(leia.next());
       
        p4.print();



    }
}
