public class Goldfish extends Peixe {
    
}
