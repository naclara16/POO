public class Canguru extends Mamifero {

    @Override
    public void locomover() {
        System.out.println("Saltando");
        
    }
    
}
