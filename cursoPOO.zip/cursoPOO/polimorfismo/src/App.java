public class App {
    public static void main(String[] args) throws Exception {
        // Animal a = new Animal(); não pode ser instanciado
        Mamifero m = new Mamifero();
        Reptil r = new Reptil();
        Peixe p = new Peixe();
        Ave a = new Ave();
        Canguru c = new Canguru();
        Cachorro k = new Cachorro();


        k.locomover();
        c.locomover();


    }
}
