public class Arara extends Ave {
    
}
