public class Cachorro extends Mamifero {
    
}
