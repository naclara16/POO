package gui;

public class Janela {
    
}
