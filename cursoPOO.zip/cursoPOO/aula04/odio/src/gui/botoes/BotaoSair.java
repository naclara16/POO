package gui.botoes;

public class BotaoSair {
    
}
