package gui.botoes;

public class BotaoPause {
    
}
