package gui;

public class MiniaturaVideo {
    
}
