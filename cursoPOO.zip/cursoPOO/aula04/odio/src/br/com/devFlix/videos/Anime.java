package br.com.devFlix.videos;

public class Anime {
    
}
