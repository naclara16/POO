import br.com.devFlix.videos.*;
import gui.*;
import gui.botoes.*;



public class App {
    public static void main(String[] args) throws Exception {
        Filme filme = new Filme();

        Novela novela = new Novela();

        Documentario docu = new Documentario();

        Serie serie = new Serie();

        Janela janelinha = new Janela();
        MiniaturaVideo mini = new MiniaturaVideo();

        BotaoPlay botao = new BotaoPlay();







        
    }
}
