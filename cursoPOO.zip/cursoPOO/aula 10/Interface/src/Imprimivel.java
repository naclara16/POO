public interface Imprimivel {
    final char nlin = '\n';

    public String formatoString();
    public void formatoSystemOut();

}
