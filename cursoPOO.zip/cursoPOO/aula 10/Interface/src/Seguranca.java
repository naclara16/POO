public interface Seguranca {
    public boolean validar();
}
