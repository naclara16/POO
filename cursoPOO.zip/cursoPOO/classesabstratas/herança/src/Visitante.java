public class Visitante extends Pessoa {
    // n precisa ter nada pq ele ja está puxando as coisas de pessoa
}
