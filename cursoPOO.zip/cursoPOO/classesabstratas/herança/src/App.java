public class App {
    public static void main(String[] args) throws Exception {
        //Pessoa p1 = new Pessoa(); não posso intanciar a classe pessoa pq ela é uma classe abstrata
            
       
    }
}
