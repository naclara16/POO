import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        
        Celular cell = new Celular(); // declarando um objeto do tipo celular = instanciando um objeto
        Scanner leia = new Scanner(System.in);
        /*cell.nome = "Xiomi 10";
        cell.tamanhoTela = 6.1f;
        cell.espacoAmazenamento = 256;
        cell.sistemaOperacional = "Android";

    System.out.format("Celular %s com tela de %f, com %d e SO %s",cell.nome, cell.tamanhoTela,cell.espacoAmazenamento, cell.sistemaOperacional);*/
        System.out.println("Digite o nome do celular: ");
        cell.nome = leia.nextLine();
        System.out.println("Digite o tamanho da tela: ");
        cell.tamanhoTela = leia.nextFloat();
        System.out.println("Digite a memoria: ");
        cell.espacoAmazenamento = leia.nextInt();
        System.out.println("Digite o Sistema Operacional: ");
        cell.sistemaOperacional = leia.next();
        
        cell.imprimeDados();

    }
}
