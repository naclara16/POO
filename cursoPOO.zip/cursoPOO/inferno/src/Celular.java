public class Celular {
    // caracteristicas = atributos
    String nome;
    String sistemaOperacional;
    int espacoAmazenamento;
    float tamanhoTela;

    public Celular() {
    }

    public Celular(String nome, String sistemaOperacional, int espacoAmazenamento, float tamanhoTela) {
        this.nome = nome;
        this.sistemaOperacional = sistemaOperacional;
        this.espacoAmazenamento = espacoAmazenamento;
        this.tamanhoTela = tamanhoTela;
    }

    void imprimeDados(){
        System.out.println("****************************");
        System.out.println("Bem vindo a melhor loja de celulares");
        System.out.println("Nome: " + nome);
        System.out.println("Sistema Operacional: "+ sistemaOperacional);
        System.out.println("Memoria: " + espacoAmazenamento);
        System.out.println("Tamanho da tela: "+ tamanhoTela);
        System.out.println("**************************");
    }

    
}
