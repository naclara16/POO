public class App {
    public static void main(String[] args) throws Exception {
       
        Mamifero x = new Mamifero();
        Lobo l = new Lobo();
        Cachorro c = new Cachorro();

        
        x.emitirSom();
        l.emitirSom();
        c.emitirSom();
    }
}
