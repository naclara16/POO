public class Lobo extends Mamifero {

    @Override
    public void emitirSom() {
       System.out.println("Auuuuuuuuuuuuuu");
    }
    
    public void reagir(String frase){

    }

    public void reagir(int hora, int min){

    }

    public void reagir(boolean dono){
        
    }

    public void reagir(int idade, float peso){
        
    }

    public void reagir(float x, int y){
        
    }
}
