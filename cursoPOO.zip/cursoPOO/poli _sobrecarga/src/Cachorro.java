public class Cachorro extends Lobo {

    @Override
    public void emitirSom() {
       System.out.println("Au,Au,Au");
    }
    
}
