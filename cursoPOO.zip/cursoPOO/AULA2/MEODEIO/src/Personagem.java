import java.util.Random;

public class Personagem {
    String nome;
    int nivel;
    int forca;
    
    public Personagem() {
    }

    public Personagem(String nome, int nivel, int forca) {
        this.nome = nome;
        this.nivel = nivel;
        this.forca = forca;
    }
    
    void imprimeDados(){
        System.out.println("********************");
        System.out.println("Bem vindo ao menu de PERSONAGEM");
        System.out.println("Nome: " + nome);
        System.out.println("Nivel: " + nivel);
        System.out.println("Força: " + forca);
        System.out.println("************************");
    }


    int calcularDano() {
        Random gerador = new Random();
         // 1... 20
         // nextInt(): 9...19
         // nextInt(): 0 = 20
        int dado20Faces = 1 + gerador.nextInt(19);
        int dano = forca + dado20Faces;
         return dano;
      
    }
        
   
  
    void atacar(String alvo, String habilidade){
        int dadoCausado = calcularDano();
        if(habilidade.length() == 0){
            System.out.format("%s atacou %s e causou %d de dano.\n", nome, alvo, forca);
        }else{
            System.out.format("%s usou '%s' contra %s e causou %d de dano. \n ",
             nome, habilidade, alvo, dadoCausado);
        } 
    }
   

    
    


    
}
