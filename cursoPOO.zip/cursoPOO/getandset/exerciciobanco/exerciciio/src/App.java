public class App {
    public static void main(String[] args) throws Exception {
        ContaBanco p1 = new ContaBanco();
        p1.setNumConta(1111);
        p1.setDono("Amity");
        p1.abrirConta("ContaCorrente");



        ContaBanco p2 = new ContaBanco();
        p2.setNumConta(2222);
        p2.setDono("Luz");
        p2.abrirConta("ContaPoupança");

        p1.depositar(100);
        p2.depositar(500);
        p2.sacar(100);

        p1.sacar(150);
        p1.fecharConta();

        p1.estadoAtual();
        p2.estadoAtual();
        
    }
}
