
public class App {
    public static void main(String[] args) throws Exception {
        Caneta c1 = new Caneta("BIC", 0.4f, "PRETA", false);
        
        c1.status();
        //c1.setModelo("BIC");
        //c1.modelo = "BIC"; se é privado não tem como chamar ele direto,
        //tem que pedir a permissão pelo SET

       // c1.setPonta(0.5f);
        //c1.status();
        
    }
}
