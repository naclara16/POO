
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Personagem heroi = new Personagem();
        Scanner leia = new Scanner(System.in);
 
        System.out.println("Bem vindo ao menu de PERSONAGEM");
         System.out.println("Digite o nome do seu personagem: ");
         heroi.nome = leia.nextLine();
         System.out.println("Digite seu nivel: ");
         heroi.nivel = leia.nextInt();
         System.out.println("Digite sua força: ");
         heroi.forca = leia.nextInt();

         heroi.imprimeDados();
         heroi.atacar("Belos", "");
        
         System.out.println("Seu numero no dado foi: ");
         System.out.println( heroi.calcularDano());
      System.out.println("************************");
         

        
         
    }
       

}
